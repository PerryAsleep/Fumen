# README
Please visit the online [README](https://github.com/PerryAsleep/Fumen/blob/master/StepManiaChartGenerator/README.md).

Also please read the [README](html/src/README.md) in the `html/src` directory.