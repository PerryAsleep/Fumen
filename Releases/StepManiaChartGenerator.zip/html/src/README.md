# README
With the exception of `l.png` and `r.png` all assets included in this directory are taken from [StepMania](https://github.com/stepmania/stepmania). Most assets are from the [dance default NoteSkin](https://github.com/stepmania/stepmania/tree/5_1-new/NoteSkins/dance/default).
